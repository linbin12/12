window.onload=function(){
    sh();
    function sh(){

    var uls=document.querySelectorAll(".list");
    var choose=document.querySelector(".choose");
    var overlay=document.querySelector(".van-overlay")
    var is=choose.querySelector("i")
    var divs=choose.querySelectorAll("div");
    var inputs=document.querySelectorAll("input");
    var rightbtn=document.querySelector(".right-btn");
    // console.log(inputs)
    //保存
    rightbtn.onclick=function(){
        window.location.href="my.html"
    }
    uls[1].onclick=function(){ 
        choose.className="choose up"
        overlay.style.display="block"
    }
    overlay.onclick=function(){
        choose.className="choose down"
        overlay.style.display="none"
    }
    is.onclick=function(){
        choose.className="choose down"
        overlay.style.display="none"
    }
    divs[1].onclick=function(){
        inputs[1].value="男";
        choose.className="choose down"
        overlay.style.display="none"

    }
    divs[2].onclick=function(){
        inputs[1].value="女";
        choose.className="choose down"
        overlay.style.display="none"
    }
    divs[3].onclick=function(){
        choose.className="choose down"
        overlay.style.display="none"
    }
    }

}