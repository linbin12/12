window.onload=function(){
    fal();
    function fal(){
        var personal=document.querySelector(".personal");
        var lis=personal.querySelectorAll("li");
        var order=document.querySelector(".order");
        //获取查看全部订单按钮
        var orderli=order.querySelectorAll("li")[1];
        orderli.onclick=function(){
            window.localStorage.setItem("menuli","0");
            window.location.href="dingdan.html"
        }
        //订单副按钮
        var menu=document.querySelector(".menu");
        var menuli=menu.querySelectorAll("li");
        for(let i=0;i<menuli.length;i++){
            menuli[i].index=i;
            menuli[i].onclick=function(){
                i=i+1
                window.localStorage.setItem("menuli",i);
                window.location.href="dingdan.html"
            }
        }
        //个人信息
        lis[0].onclick=function(){
            window.location.href="geren.html";
        }
        //地址
        lis[1].onclick=function(){
            window.location.href="address.html";
        }
        //绑定手机
        lis[2].onclick=function(){
            window.location.href="bangdingshouji.html";
        }


    }
    
}