window.onload=function(){
    menu();
    function menu(){
        var omenu=document.querySelector(".menu");
        var lis=omenu.querySelectorAll("li");
        var orders=document.querySelectorAll(".main");
        var back=document.querySelector(".back");
        //返回按钮
        console.log(orders)
        back.onclick=function(){
            window.history.back();
        }
        var indexs=Number(window.localStorage.getItem("menuli"));
        // 
        for(var i=0;i<lis.length;i++){
            lis[i].className="";
            orders[i].style.display="none";
            lis[indexs].className="ored";
            orders[indexs].style.display="block"
        }
        
        for(var i =0 ; i < lis.length;i++){
            lis[i].index=i;
            lis[i].onclick=function(){
                for(var j =0 ; j < lis.length;j++){
                  lis[j].className="";
                    orders[j].style.display="none";
                }
                this.className="ored";
                 orders[this.index].style.display="block"
            }
           
        }
        

        window.localStorage.setItem('订单编号', JSON.stringify(list))
    }
}