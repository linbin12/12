window.onload=function(){
    fks();
    function fks(){
        var back=document.querySelector(".back");
        back.onclick=function(){
            window.location.href="queren.html"
        }
    }
}