window.onload=function(){
    var van=document.querySelector(".van-switch");
    var node=document.querySelector(".van-switch_node");
   var inputs=document.querySelectorAll("input");
   var sure=document.querySelector(".sure-btn");
   var oback=document.querySelector(".back");
   var a=true;
     oback.onclick=function(){
        window.history.go(-1);
     }
    van.onclick=function(){
        if(a==true){
        van.style.background="red";
        node.className="van-switch_node move";
        node.classList.remove("moveback");
        inputs[1].setAttribute("type","text")
        }else{
            van.style.background="white";
            node.className="van-switch_node moveback"
            node.classList.remove("move");
            inputs[1].setAttribute("type","password")
        }
        a=!a;
    }
    sure.onclick=function(){

    }

}